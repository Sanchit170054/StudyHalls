package studyhall2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Q8 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection conn= DriverManager.getconnnection("jdbc:hive2://localhost:10000/default","","");
		
		Statement stmt=conn.createStatement();
		stmt.execute("create table bucketTable(AthleteName string,Age Int,Country string,Year int,Closing_Date string,Sport string,
		Gold_Medals int,Silver_Medals int, Bronze_Medals int, Total_Medals int) clustered by(Country) into 5 buckets 
		ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'");
		
		System.out.println("Olympic Partition Table Created Successfully");
		
		Statement stmt2=conn.createStatement();
		stmt2.execute("insert overwrite table bucketTable select AthleteName, Age, Country, Year, Closing_Date, Sprot, Gold_Medals,
		Silver_Medals, Bronze_Medals, Total_Medals from olympicTable;
		
		System.out.println("Data loaded successfully");
		conn.close();
	}
}