package studyHall2;

import java.sql.Connnection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Q2 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection conn= DriverManager.getconnnection("jdbc:hive2://localhost:10000/default","","");
		
		Statement stmt=conn.createStatement();
		stmt.execute("load data local inpath '/home/cloudera/employee.csv' into table EmployeeTable");
		
		Statement stmt2=conn.createStatement();
		stmt2.execute("load data local inpath '/home/cloudera/salary.csv' into table SalaryTable");
		
		conn.close();
	}
}