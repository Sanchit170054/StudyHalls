package studyHall2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Q5 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection conn= DriverManager.getconnnection("jdbc:hive2://localhost:10000/jdbc","","");
		
		Statement stmt=conn.createStatement();
		stmt.execute("create table olympicTable(AthleteName string,Age Int,Country string,Year Int,Closing_Date string,Sprot string,Gold_Medals int,
		Silver_Medals int, Bronze_Medals int, Total_Medals int) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'");
		
		System.out.println("Table for Olympic Data is created Successfully");
		conn.close();
	}
}