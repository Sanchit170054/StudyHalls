package studyHall2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Q7 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection conn= DriverManager.getconnnection("jdbc:hive2://localhost:10000/default","","");
		
		Statement stmt=conn.createStatement();
		stmt.execute("create table partitionTable(AthleteName string,Age Int,Country string,Closing_Date string,Sprot string,Gold_Medals int,
		Silver_Medals int, Bronze_Medals int, Total_Medals int) partitioned by(Year Int)");
		
		System.out.println("Partition table is created Successfully");
		
		Statement stmt2=conn.createStatement();
		stmt2.execute("insert overwrite table partitionTable partition(Year) select AthleteName, Age, Country, Closing_Date, Sprot, Gold_Medals,
		Silver_Medals, Bronze_Medals, Total_Medals, Year from olympicTable;
		
		System.out.println("Data loaded successfully");
		
		conn.close();
	}
}